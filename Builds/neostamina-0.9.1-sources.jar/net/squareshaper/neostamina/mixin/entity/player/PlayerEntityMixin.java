package net.squareshaper.neostamina.mixin.entity.player;

import com.google.common.collect.HashMultimap;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3611;
import net.minecraft.class_5132;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin extends class_1309 implements StaminaUsingEntity {
    @Shadow
    public abstract boolean method_56992();

    @Shadow
    public abstract boolean isCreative();

    protected PlayerEntityMixin(class_1299<? extends class_1309> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Inject(method = "tick", at = @At("TAIL"))
    public void neostamina$tick(CallbackInfo ci) {
        if (!this.method_37908().method_8608()) {

            this.method_6127().method_59932(getNaturalStaminaModifiers());
            if (Neostamina.SERVER_CONFIG.players_can_exhaust) {
                Optional<class_6880.class_6883<class_1291>> exhausted_status_effect = class_7923.field_41174.method_55841(Neostamina.SERVER_CONFIG.exhausted_status_effect_identifier.get());
                if (exhausted_status_effect.isPresent()) {
                    if (this.neostamina$getStamina() <= 0) {
                        if (!this.method_6059(exhausted_status_effect.get())) {
                            this.method_6092(new class_1293(exhausted_status_effect.get(), -1, 0, false, false, true));
                        }
                    } else {
                        this.method_6016(exhausted_status_effect.get());
                    }
                }
            }
        }
    }

    @Inject(method = "createPlayerAttributes", at = @At("RETURN"))
    private static void neostamina$createPlayerAttributes(CallbackInfoReturnable<class_5132.class_5133> cir) {
        cir.getReturnValue()
                .method_26868(Neostamina.MIN_MAX_STAMINA, 0.0)
                .method_26868(Neostamina.MAX_STAMINA, 0.0)
                .method_26868(Neostamina.DEPLETED_STAMINA_REGENERATION_DELAY_THRESHOLD, 0.0)
                .method_26868(Neostamina.STAMINA_REGENERATION_DELAY_THRESHOLD, 0.0)
                .method_26868(Neostamina.STAMINA_TICK_THRESHOLD, 0.0)
        ;
    }

    @Inject(method = "jump", at = @At("HEAD"), cancellable = true)
    public void neostamina$pre_jump(CallbackInfo ci) {
        if (!this.isCreative() && !this.method_7325() && Neostamina.SERVER_CONFIG.staminaConsumptionAndActionBlockingRules.jumping_is_blocked_by_stamina && this.neostamina$getStamina() <= 0) {
            ci.cancel();
        }
    }

    @Inject(method = "jump", at = @At("RETURN"))
    public void neostamina$post_jump(CallbackInfo ci) {
        if (!this.isCreative() && !this.method_7325() && Neostamina.SERVER_CONFIG.staminaConsumptionAndActionBlockingRules.jumping_costs_stamina) {
            if (this.method_5624()) {
                this.neostamina$addStamina(-this.neostamina$getSprintJumpingActionStaminaCost(), Neostamina.SERVER_CONFIG.shouldDisableStaminaRegeneration.jumping_disables_stamina_regen);
            } else {
                this.neostamina$addStamina(-this.neostamina$getJumpingActionStaminaCost(), Neostamina.SERVER_CONFIG.shouldDisableStaminaRegeneration.jumping_disables_stamina_regen);
            }
        }
    }

    @Override
    protected void method_6010(class_6862<class_3611> fluid) {
        if ((this.isCreative() || this.method_7325()) || !Neostamina.SERVER_CONFIG.staminaConsumptionAndActionBlockingRules.swimming_is_blocked_by_stamina || this.neostamina$getStamina() > 0) {
            super.method_6010(fluid);
        }
    }

    @Unique
    private HashMultimap<class_6880<class_1320>, class_1322> getNaturalStaminaModifiers() {
        HashMultimap<class_6880<class_1320>, class_1322> hashMultimap = HashMultimap.create();
        hashMultimap.put(Neostamina.STAMINA_REGENERATION, new class_1322(Neostamina.id("natural_stamina_regeneration_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_stamina_regeneration, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.STAMINA_REGENERATION_EFFECT, new class_1322(Neostamina.id("stamina_regeneration_effect_modifier"), Neostamina.SERVER_CONFIG.stamina_regeneration_effect, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.MIN_MAX_STAMINA, new class_1322(Neostamina.id("natural_min_max_stamina_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_min_max_stamina, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.MAX_STAMINA, new class_1322(Neostamina.id("natural_max_stamina_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_max_stamina, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.DEPLETED_STAMINA_REGENERATION_DELAY_THRESHOLD, new class_1322(Neostamina.id("natural_depleted_stamina_regeneration_delay_threshold_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_depleted_stamina_regeneration_delay_threshold, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.STAMINA_REGENERATION_DELAY_THRESHOLD, new class_1322(Neostamina.id("natural_stamina_regeneration_delay_threshold_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_stamina_regeneration_delay_threshold, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.STAMINA_TICK_THRESHOLD, new class_1322(Neostamina.id("natural_stamina_tick_threshold_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_stamina_tick_threshold, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.RESERVED_STAMINA, new class_1322(Neostamina.id("natural_reserved_stamina_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_reserved_stamina, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.ITEM_SINGLE_USE_STAMINA_COST, new class_1322(Neostamina.id("natural_item_single_use_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_item_single_use_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.ITEM_CONTINUOUS_USE_STAMINA_COST, new class_1322(Neostamina.id("natural_item_continuous_use_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_item_continuous_use_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.SPRINTING_TICK_STAMINA_COST, new class_1322(Neostamina.id("natural_sprinting_tick_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_sprinting_tick_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.WALKING_TICK_STAMINA_COST, new class_1322(Neostamina.id("natural_walking_tick_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_walking_tick_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.CRAWLING_TICK_STAMINA_COST, new class_1322(Neostamina.id("natural_crawling_tick_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_crawling_tick_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.SWIMMING_TICK_STAMINA_COST, new class_1322(Neostamina.id("natural_swimming_tick_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_swimming_tick_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.WALKING_UNDERWATER_TICK_STAMINA_COST, new class_1322(Neostamina.id("natural_walking_underwater_tick_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_walking_underwater_tick_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.WALKING_IN_WATER_TICK_STAMINA_COST, new class_1322(Neostamina.id("natural_walking_in_water_tick_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_walking_in_water_tick_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.CLIMBING_TICK_STAMINA_COST, new class_1322(Neostamina.id("natural_climbing_tick_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_climbing_tick_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.MINING_TICK_STAMINA_COST, new class_1322(Neostamina.id("natural_mining_tick_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_mining_tick_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.ROWING_LAND_TICK_STAMINA_COST, new class_1322(Neostamina.id("natural_rowing_land_tick_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_rowing_land_tick_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.ROWING_WATER_TICK_STAMINA_COST, new class_1322(Neostamina.id("natural_rowing_water_tick_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_rowing_water_tick_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.ROWING_ICE_TICK_STAMINA_COST, new class_1322(Neostamina.id("natural_rowing_ice_tick_stamina_cost_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_rowing_ice_tick_stamina_cost, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.SPRINT_JUMPING_ACTION_STAMINA_COST, new class_1322(Neostamina.id("natural_action_stamina_cost_sprint_jumping_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_action_stamina_cost_sprint_jumping, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.JUMPING_ACTION_STAMINA_COST, new class_1322(Neostamina.id("natural_action_stamina_cost_jumping_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_action_stamina_cost_jumping, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.ATTACKING_ACTION_STAMINA_COST, new class_1322(Neostamina.id("natural_action_stamina_cost_attacking_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_action_stamina_cost_attack, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.INTERACTION_ACTION_STAMINA_COST, new class_1322(Neostamina.id("natural_action_stamina_cost_interaction_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_action_stamina_cost_interaction, class_1322.class_1323.field_6328));
        hashMultimap.put(Neostamina.SHIELD_BLOCK_ACTION_STAMINA_COST, new class_1322(Neostamina.id("natural_action_stamina_cost_shield_block_modifier"), Neostamina.SERVER_CONFIG.naturalPlayerAttributeValues.natural_action_stamina_cost_shield_block, class_1322.class_1323.field_6328));
        return hashMultimap;
    }

    @WrapMethod(method = "isBlockBreakingRestricted")
    public boolean neostamina$wrapBlockBreakingRestricted(class_1937 world, class_2338 pos, class_1934 gameMode, Operation<Boolean> original) {
        if (!this.isCreative() && !this.method_7325() && Neostamina.SERVER_CONFIG.staminaConsumptionAndActionBlockingRules.breaking_blocks_is_blocked_by_stamina && this.neostamina$getStamina() <= 0) {
            return true;
        } else {
            return original.call(world, pos, gameMode);
        }
    }

    @WrapMethod(method = "interact")
    public class_1269 neostamina$wrapEntityInteract(class_1297 entity, class_1268 hand, Operation<class_1269> original) {
        class_1269 result = original.call(entity, hand);

        if ((result == class_1269.field_5812 || result == class_1269.field_51370) && !this.isCreative() && !this.method_7325()) {
            if (Neostamina.SERVER_CONFIG.staminaConsumptionAndActionBlockingRules.interacting_is_blocked_by_stamina && this.neostamina$getStamina() <= 0) {
                return class_1269.field_5814;
            }
            if (Neostamina.SERVER_CONFIG.staminaConsumptionAndActionBlockingRules.interacting_costs_stamina && this.neostamina$getInteractionActionStaminaCost() > 0) {
                this.neostamina$addStamina(-this.neostamina$getInteractionActionStaminaCost(), Neostamina.SERVER_CONFIG.shouldDisableStaminaRegeneration.interacting_disables_stamina_regen);
            }
        }

        return result;
    }
}
