package net.squareshaper.neostamina.networking;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.squareshaper.neostamina.registry.PayloadRegistry;

public record UseStaminaPayload(float amount, boolean blockStaminaRegen) implements class_8710 {
    public static final class_8710.class_9154<UseStaminaPayload> ID = new class_8710.class_9154<>(PayloadRegistry.USE_STAMINA_PAYLOAD_IDENTIFIER);
    public static final class_9139<class_2540, UseStaminaPayload> CODEC = class_9139.method_56435(
            class_9135.field_48552, UseStaminaPayload::amount,
            class_9135.field_48547, UseStaminaPayload::blockStaminaRegen,
            UseStaminaPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
