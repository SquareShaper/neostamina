package net.squareshaper.neostamina.registry;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.networking.UseStaminaPayload;

public class PayloadRegistry {
    public static final class_2960 USE_STAMINA_PAYLOAD_IDENTIFIER = Neostamina.id("use_stamina_payload");
    public static final class_8710.class_9155<? super class_9129, UseStaminaPayload> USE_STAMINA_PAYLOAD_TYPE = registerServerBoundPayload(UseStaminaPayload.ID, UseStaminaPayload.CODEC);


    public static void init() {

    }

    public static <T extends class_8710> class_8710.class_9155<? super class_9129, T> registerServerBoundPayload(class_8710.class_9154<T> id, class_9139<? super class_9129, T> codec) {
        return PayloadTypeRegistry.playC2S().register(id, codec);
    }
}
