package net.squareshaper.neostamina.mixin.entity;


import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3532;
import net.minecraft.class_5132;
import net.minecraft.class_6880;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;
import net.squareshaper.neostamina.registry.StatusEffectsRegistry;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 implements StaminaUsingEntity {

    @Shadow
    public abstract double getAttributeValue(class_6880<class_1320> attribute);

    @Shadow
    public abstract boolean isUsingItem();

    @Shadow
    public abstract void stopUsingItem();

    @Shadow
    protected class_1799 activeItemStack;

    @Shadow
    public abstract float getHealth();

    @Shadow
    public abstract float getAbsorptionAmount();

    @Shadow
    public abstract boolean hasStatusEffect(class_6880<class_1291> effect);

    @Shadow
    public abstract @Nullable class_1293 getStatusEffect(class_6880<class_1291> effect);

    @Unique
    private int staminaTickTimer = 0;
    @Unique
    private int staminaSyncTimer = 0;
    @Unique
    private int staminaRegenDoublingTimer = 0;
    @Unique
    private int depletedStaminaRegenerationDelayTimer = 0;
    @Unique
    private int staminaRegenerationDelayTimer = 0;
    @Unique
    private boolean delayStaminaRegeneration = false;
    @Unique
    private Float oldStamina = null;
    @Unique
    private Float oldMaxStamina = null;
    @Unique
    private boolean applyOldStamina = true;
    @Unique
    private boolean applyMaxStamina = false;

    @Unique
    private static final class_2940<Float> STAMINA = class_2945.method_12791(class_1309.class, class_2943.field_13320);
    @Unique
    private static final class_2940<Float> MAX_STAMINA = class_2945.method_12791(class_1309.class, class_2943.field_13320);

    public LivingEntityMixin(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Inject(method = "initDataTracker", at = @At("RETURN"))
    protected void neostamina$initDataTracker(class_2945.class_9222 builder, CallbackInfo ci) {
        builder.method_56912(STAMINA, 20.0F);
        builder.method_56912(MAX_STAMINA, 20.0F);
    }

    @Inject(method = "createLivingAttributes", at = @At("RETURN"))
    private static void neostamina$createLivingAttributes(CallbackInfoReturnable<class_5132.class_5133> cir) {
        cir.getReturnValue()
                .method_26867(Neostamina.STAMINA_REGENERATION)
                .method_26867(Neostamina.MIN_MAX_STAMINA)
                .method_26867(Neostamina.MAX_STAMINA)
                .method_26867(Neostamina.DEPLETED_STAMINA_REGENERATION_DELAY_THRESHOLD)
                .method_26867(Neostamina.STAMINA_REGENERATION_DELAY_THRESHOLD)
                .method_26867(Neostamina.STAMINA_TICK_THRESHOLD)
                .method_26867(Neostamina.RESERVED_STAMINA)
                .method_26867(Neostamina.ITEM_SINGLE_USE_STAMINA_COST)
                .method_26867(Neostamina.ITEM_CONTINUOUS_USE_STAMINA_COST)
                .method_26867(Neostamina.SPRINTING_TICK_STAMINA_COST)
                .method_26867(Neostamina.WALKING_TICK_STAMINA_COST)
                .method_26867(Neostamina.CRAWLING_TICK_STAMINA_COST)
                .method_26867(Neostamina.SWIMMING_TICK_STAMINA_COST)
                .method_26867(Neostamina.WALKING_UNDERWATER_TICK_STAMINA_COST)
                .method_26867(Neostamina.WALKING_IN_WATER_TICK_STAMINA_COST)
                .method_26867(Neostamina.CLIMBING_TICK_STAMINA_COST)
                .method_26867(Neostamina.MINING_TICK_STAMINA_COST)
                .method_26867(Neostamina.ROWING_LAND_TICK_STAMINA_COST)
                .method_26867(Neostamina.ROWING_WATER_TICK_STAMINA_COST)
                .method_26867(Neostamina.ROWING_ICE_TICK_STAMINA_COST)
                .method_26867(Neostamina.JUMPING_ACTION_STAMINA_COST)
                .method_26867(Neostamina.SPRINT_JUMPING_ACTION_STAMINA_COST)
                .method_26867(Neostamina.ATTACKING_ACTION_STAMINA_COST)
                .method_26867(Neostamina.INTERACTION_ACTION_STAMINA_COST)
                .method_26867(Neostamina.SHIELD_BLOCK_ACTION_STAMINA_COST)
        ;
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("HEAD"))
    public void neostamina$readCustomDataFromNbt_head(class_2487 nbt, CallbackInfo ci) {
        float stamina;
        if (nbt.method_10573("stamina", class_2520.field_33263)) {
            stamina = nbt.method_10583("stamina");
        } else {
            stamina = Float.MIN_VALUE;
        }
        if (stamina != Float.MIN_VALUE) {
            this.oldStamina = stamina;
        }

        float maxStamina;
        if (nbt.method_10573("max_stamina", class_2520.field_33263)) {
            maxStamina = nbt.method_10583("max_stamina");
        } else {
            maxStamina = Float.MIN_VALUE;
        }
        if (maxStamina != Float.MIN_VALUE) {
            this.oldMaxStamina = maxStamina;
        }
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    public void neostamina$readCustomDataFromNbt_tail(class_2487 nbt, CallbackInfo ci) {
        if (nbt.method_10573("stamina", class_2520.field_33263)) {
            this.neostamina$setStamina(nbt.method_10583("stamina"));
        }

        if (nbt.method_10573("max_stamina", class_2520.field_33263)) {
            this.neostamina$setMaxStamina(nbt.method_10583("max_stamina"));
        }
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    public void neostamina$writeCustomDataToNbt(class_2487 nbt, CallbackInfo ci) {
        nbt.method_10548("max_stamina", this.neostamina$getMaxStamina());
        nbt.method_10548("stamina", this.neostamina$getStamina());
    }

    @Inject(method = "tick", at = @At("TAIL"))
    public void neostamina$tick(CallbackInfo ci) {
        int staminaSyncTimerMax = 20;

        this.staminaSyncTimer++;
        if (this.staminaSyncTimer >= staminaSyncTimerMax) {
            this.neostamina$syncStaminaToHealth();
            this.staminaSyncTimer = 0;
        }
        if (!this.method_37908().field_9236) {

            this.staminaTickTimer++;

            if (this.neostamina$getStamina() <= 0 && this.delayStaminaRegeneration) {
                this.depletedStaminaRegenerationDelayTimer = 0;
                this.staminaRegenerationDelayTimer = this.neostamina$getStaminaRegenerationDelayThreshold();
                this.delayStaminaRegeneration = false;
            }
            if (this.neostamina$getStamina() > 0 && !this.delayStaminaRegeneration) {
                this.delayStaminaRegeneration = true;
            }
            if (this.depletedStaminaRegenerationDelayTimer <= this.neostamina$getDepletedStaminaRegenerationDelayThreshold()) {
                this.depletedStaminaRegenerationDelayTimer++;
            }
            if (this.staminaRegenerationDelayTimer <= this.neostamina$getStaminaRegenerationDelayThreshold()) {
                this.staminaRegenerationDelayTimer++;
            }

            if (this.staminaTickTimer > this.neostamina$getStaminaTickThreshold()
                            && this.depletedStaminaRegenerationDelayTimer > this.neostamina$getDepletedStaminaRegenerationDelayThreshold()
                            && this.staminaRegenerationDelayTimer > this.neostamina$getStaminaRegenerationDelayThreshold()) {
                if (this.neostamina$getStamina() < this.neostamina$getUnreservedStamina()) {
                    this.neostamina$addStamina(this.neostamina$getRegeneratedStamina(), false);
                }

                if (this.neostamina$getStamina() > this.neostamina$getUnreservedStamina() || this.neostamina$getRegeneratedStamina() < 0) {
                    this.neostamina$setStamina(this.neostamina$getUnreservedStamina());
                }
                this.staminaTickTimer = 0;
            }

            if (this.isUsingItem() && this.activeItemStack.method_31573(Neostamina.CONTINUOUS_USING_COSTS_STAMINA) && Neostamina.SERVER_CONFIG.staminaConsumtionAndActionBlockingRules.using_item_is_blocked_by_stamina && this.neostamina$getStamina() <= 0) {
                if (((class_1309) (Object) this) instanceof class_1657 playerEntity) {
                    playerEntity.method_7357().method_7906(this.activeItemStack.method_7909(), Neostamina.SERVER_CONFIG.item_use_cooldown_when_no_stamina);
                }
                this.stopUsingItem();
            }
            if (this.applyOldStamina) {
                if (this.applyMaxStamina) {
                    this.oldStamina = this.neostamina$getHealthToStamina();
                    this.oldMaxStamina = this.neostamina$getHealthToStamina();
                    this.applyMaxStamina = false;
                }
                if (this.oldMaxStamina != null) {
                    this.neostamina$setMaxStamina(this.oldMaxStamina);
                    this.oldMaxStamina = null;
                }
                if (this.oldStamina != null) {
                    this.neostamina$setStamina(this.oldStamina);
                    this.oldStamina = null;
                }
            } else {
                this.applyOldStamina = true;
            }
        }
    }

    @Inject(method = "tickItemStackUsage", at = @At("HEAD"))
    protected void neostamina$tickItemStackUsage(class_1799 stack, CallbackInfo ci) {
        if (stack.method_31573(Neostamina.CONTINUOUS_USING_COSTS_STAMINA) && neostamina$getItemContinuousUseStaminaCost() > 0) {
            this.neostamina$addStamina(-neostamina$getItemContinuousUseStaminaCost(), true);
        }
    }

    @Override
    public int neostamina$getDepletedStaminaRegenerationDelayThreshold() {
        return (int) this.getAttributeValue(Neostamina.DEPLETED_STAMINA_REGENERATION_DELAY_THRESHOLD);
    }

    @Override
    public int neostamina$getStaminaRegenerationDelayThreshold() {
        return (int) this.getAttributeValue(Neostamina.STAMINA_REGENERATION_DELAY_THRESHOLD);
    }

    @Override
    public int neostamina$getStaminaTickThreshold() {
        return (int) this.getAttributeValue(Neostamina.STAMINA_TICK_THRESHOLD);
    }

    @Override
    public float neostamina$getRegeneratedStamina() {
        // this.staminaRegenDoublingTimer * this.neostamina$getStaminaTickThreshold() should be twenty times the amount of seconds passed since starting regeneration, always
        return this.neostamina$getStaminaRegeneration() * (1 + ((this.staminaRegenDoublingTimer * this.neostamina$getStaminaTickThreshold()) % Neostamina.SERVER_CONFIG.stamina_regeneration_doubling_interval));
    }

    @Override
    public float neostamina$getStaminaRegeneration() {
        return (float) this.getAttributeValue(Neostamina.STAMINA_REGENERATION);
    }

    @Override
    public float neostamina$getUnreservedStamina() {
        return this.neostamina$getMaxStamina() - ((this.neostamina$getMaxStamina() * this.neostamina$getReservedStamina()) / 100);
    }

    @Override
    public float neostamina$getMaxStamina() {
        return this.field_6011.method_12789(MAX_STAMINA);
    }

    @Override
    public float neostamina$getMaxStaminaAttribute() {return (float) this.getAttributeValue(Neostamina.MAX_STAMINA);}

    @Override
    public float neostamina$getReservedStamina() {
        return (float) this.getAttributeValue(Neostamina.RESERVED_STAMINA);
    }

    @Override
    public float neostamina$getItemSingleUseStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.ITEM_SINGLE_USE_STAMINA_COST);
    }

    @Override
    public float neostamina$getItemContinuousUseStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.ITEM_CONTINUOUS_USE_STAMINA_COST);
    }

    @Override
    public float neostamina$getSprintingTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.SPRINTING_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getWalkingTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.WALKING_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getCrawlingTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.CRAWLING_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getSwimmingTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.SWIMMING_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getWalkingUnderwaterTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.WALKING_UNDERWATER_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getWalkingInWaterTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.WALKING_IN_WATER_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getClimbingTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.CLIMBING_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getMiningTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.MINING_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getRowingLandTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.ROWING_LAND_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getRowingWaterTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.ROWING_WATER_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getRowingIceTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.ROWING_ICE_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getJumpingActionStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.JUMPING_ACTION_STAMINA_COST);
    }

    @Override
    public float neostamina$getSprintJumpingActionStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.SPRINT_JUMPING_ACTION_STAMINA_COST);
    }

    @Override
    public float neostamina$getAttackActionStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.ATTACKING_ACTION_STAMINA_COST);
    }

    @Override
    public float neostamina$getInteractionActionStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.INTERACTION_ACTION_STAMINA_COST);
    }

    @Override
    public float neostamina$getShieldBlockActionStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.SHIELD_BLOCK_ACTION_STAMINA_COST);
    }

    @Override
    public void neostamina$addStamina(float amount, boolean shouldPauseRegeneration) {
        float f = this.neostamina$getStamina();
        this.neostamina$setStamina(f + amount);
        if (shouldPauseRegeneration) {
            this.staminaRegenerationDelayTimer = 0;
            this.staminaTickTimer = 0;
        }
    }

    @Override
    public float neostamina$getStamina() {
        return this.field_6011.method_12789(STAMINA);
    }

    @Override
    public void neostamina$setStamina(float stamina) {
        this.field_6011.method_12778(STAMINA, class_3532.method_15363(stamina, -0.1F, this.neostamina$getUnreservedStamina()));
    }

    @Override
    public void neostamina$setApplyOldStamina(boolean applyOldStamina) {
        this.applyOldStamina = applyOldStamina;
    }

    @Override
    public void neostamina$setApplyMaxStamina(boolean applyMaxStamina) {
        this.applyMaxStamina = applyMaxStamina;
    }

    @Override
    public void neostamina$setMaxStamina(float maxStamina) {
        this.field_6011.method_12778(MAX_STAMINA, class_3532.method_15363(maxStamina, this.neostamina$getMinMaxStamina(), maxStamina));
    }

    @Override
    public float neostamina$getMinMaxStamina() {
        return (float) this.getAttributeValue(Neostamina.MIN_MAX_STAMINA);
    }

    @Override
    public float neostamina$getHealthToStamina() {
        return (float) ((this.getHealth() + this.getAbsorptionAmount()) * (this.getAttributeValue(Neostamina.MAX_STAMINA) / 20));
    }

    @Override
    public void neostamina$syncStaminaToHealth() {
        this.neostamina$setMaxStamina(this.neostamina$getHealthToStamina());
        this.neostamina$setStamina(Math.min(this.neostamina$getStamina(), this.neostamina$getMaxStamina()));
    }

    @Inject(method = "damage", at = @At("TAIL"))
    private void neostamina$damage(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        this.neostamina$syncStaminaToHealth();
    }

    @Inject(method = "heal", at = @At("TAIL"))
    private void neostamina$heal(float amount, CallbackInfo ci) {
        this.neostamina$syncStaminaToHealth();
    }

    @Inject(method = "blockedByShield", at = @At("RETURN"))
    private void neostamina$block(class_1282 source, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue() && Neostamina.SERVER_CONFIG.staminaConsumtionAndActionBlockingRules.blocking_with_shield_costs_stamina && this.neostamina$getShieldBlockActionStaminaCost() > 0) {
            this.neostamina$addStamina(-this.neostamina$getShieldBlockActionStaminaCost(), true);
        }
    }

    @WrapMethod(method = "hasStatusEffect")
    private boolean neostamina$fakeHasMiningFatigue(class_6880<class_1291> effect, Operation<Boolean> original) {
        boolean result = original.call(effect);
        if (effect != class_1294.field_5901) {
            return result;
        }

        if (!result && this.hasStatusEffect(StatusEffectsRegistry.EXHAUSTION)) {
            return true;
        }

        return result;
    }

    @WrapMethod(method = "getStatusEffect")
    private @Nullable class_1293 neostamina$fakeMiningFatigueInEffectList(class_6880<class_1291> effect, Operation<class_1293> original) {
        class_1293 found = original.call(effect);
        if (effect != class_1294.field_5901) {
            return found;
        }

        class_1293 exhaustion = this.getStatusEffect(StatusEffectsRegistry.EXHAUSTION);
        if (found == null && exhaustion != null) {
            return new class_1293(class_1294.field_5901, exhaustion.method_5584(), exhaustion.method_5578(), exhaustion.method_5591(), exhaustion.method_5581(), exhaustion.method_5592());
        }
        return found;
    }
}
