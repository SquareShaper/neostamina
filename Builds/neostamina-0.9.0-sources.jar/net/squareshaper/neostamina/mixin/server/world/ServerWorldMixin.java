package net.squareshaper.neostamina.mixin.server.world;

import net.minecraft.class_1309;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(class_3218.class)
public class ServerWorldMixin {
    @Shadow
    @Final
    List<class_3222> players;

    @Inject(method = "wakeSleepingPlayers", at = @At("HEAD"))
    public void neostamina$wakeSleepingPlayers(CallbackInfo ci) {
        this.players.stream().filter(class_1309::method_6113).toList().forEach(player -> ((StaminaUsingEntity) player).neostamina$setApplyMaxStamina(true));
    }
}
