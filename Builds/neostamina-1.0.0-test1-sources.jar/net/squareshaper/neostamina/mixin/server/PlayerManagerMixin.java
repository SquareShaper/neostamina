package net.squareshaper.neostamina.mixin.server;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3324.class)
public class PlayerManagerMixin {

    @Inject(method = "respawnPlayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;onSpawn()V"))
    protected void neostamina$respawnPlayer(class_3222 player, boolean alive, class_1297.class_5529 removalReason, CallbackInfoReturnable<class_3222> cir, @Local(ordinal = 1) class_3222 serverPlayerEntity) {
        ((StaminaUsingEntity) serverPlayerEntity).neostamina$setApplyMaxStamina(true);
    }
}
