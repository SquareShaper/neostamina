package net.squareshaper.neostamina.mixin.server.network;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3442;
import net.minecraft.class_3468;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3222.class)
public abstract class ServerPlayerEntityMixin extends class_1657 implements StaminaUsingEntity {

    @Shadow public abstract class_3442 getStatHandler();

    public ServerPlayerEntityMixin(class_1937 world, class_2338 pos, float yaw, GameProfile gameProfile) {
        super(world, pos, yaw, gameProfile);
    }

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 0))
    private void neostamina$increaseTravelMotionStats_swimming(CallbackInfo ci) {
        if (!this.method_31549().field_7480) {
            this.neostamina$addStamina(-this.neostamina$getSwimmingTickStaminaCost());
        }
    }

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 1))
    private void neostamina$increaseTravelMotionStats_walk_underwater(CallbackInfo ci) {
        if (!this.method_31549().field_7480) {
            this.neostamina$addStamina(-this.neostamina$getWalkingUnderwaterTickStaminaCost());
        }
    }

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 2))
    private void neostamina$increaseTravelMotionStats_walk_in_water(CallbackInfo ci) {
        if (!this.method_31549().field_7480) {
            this.neostamina$addStamina(-this.neostamina$getWalkingInWaterTickStaminaCost());
        }
    }

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;increaseStat(Lnet/minecraft/util/Identifier;I)V", ordinal = 3))
    private void neostamina$increaseTravelMotionStats_climbing(CallbackInfo ci) {
        if (!this.method_31549().field_7480) {
            this.neostamina$addStamina(-this.neostamina$getClimbingTickStaminaCost());
        }
    }

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 3))
    private void neostamina$increaseTravelMotionStats_sprinting(CallbackInfo ci) {
        if (!this.method_31549().field_7480) {
            this.neostamina$addStamina(-this.neostamina$getSprintingTickStaminaCost());
        }
    }

//    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 4))
//    private void neostamina$increaseTravelMotionStats_sneaking(CallbackInfo ci) {
//        if (!this.getAbilities().invulnerable) {
//            this.neostamina$addStamina(-this.neostamina$getSneakingTickStaminaCost());
//        }
//    } // no sneaking uwu

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 5))
    private void neostamina$increaseTravelMotionStats_walking(CallbackInfo ci) {
        if (!this.method_31549().field_7480) {
            this.neostamina$addStamina(-this.neostamina$getWalkingTickStaminaCost());
        }
    }

    @Inject(method = "onSpawn", at = @At("TAIL"))
    public void neostamina$onSpawn(CallbackInfo ci) {
        this.neostamina$setApplyOldStamina(false);
        if (this.getStatHandler().method_15025(class_3468.field_15419.method_14956(class_3468.field_15389)) <= 0) {
            this.neostamina$setApplyMaxStamina(true);
        }
    }


}
