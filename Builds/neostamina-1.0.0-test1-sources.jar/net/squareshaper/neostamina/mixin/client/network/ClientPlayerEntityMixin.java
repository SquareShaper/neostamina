package net.squareshaper.neostamina.mixin.client.network;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_746;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_746.class)
public abstract class ClientPlayerEntityMixin implements StaminaUsingEntity {
    @Inject(method = "canSprint", at = @At("RETURN"), cancellable = true)
    private void staminaattributes$canSprint(CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(cir.getReturnValue() && (!Neostamina.SERVER_CONFIG.sprinting_requires_stamina || this.neostamina$getStamina() > 0));
    }
}
