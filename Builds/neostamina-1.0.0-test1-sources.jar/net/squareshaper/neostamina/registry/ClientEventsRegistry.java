package net.squareshaper.neostamina.registry;

import com.github.theredbrain.resourcebarapi.ResourceBarAPI;
import com.github.theredbrain.resourcebarapi.ResourceBarAPIClient;
import me.fzzyhmstrs.fzzy_config.api.ConfigApi;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.NeostaminaClient;
import net.squareshaper.neostamina.config.ClientConfig;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;
import org.apache.commons.lang3.tuple.MutablePair;

import java.util.ArrayList;

public class ClientEventsRegistry {
    private static final String RESOURCE_BAR_IDENTIFIER_STRING = Neostamina.MOD_ID + ":stamina";
    private static final class_2960 ICON_STAMINA_CONTAINER = Neostamina.id("hud/icon_stamina_container");
    private static final class_2960 ICON_STAMINA_FULL = Neostamina.id("hud/icon_stamina_full");
    private static final class_2960 ICON_STAMINA_HALF = Neostamina.id("hud/icon_stamina_half");

    public static void initializeClientEvents() {
        HudRenderCallback.EVENT.register((matrixStack, delta) -> {
            class_310 minecraftClient = class_310.method_1551();
            class_1657 playerEntity = minecraftClient.field_1724;
            ClientConfig clientConfig = NeostaminaClient.CLIENT_CONFIG;
            if (playerEntity != null && !minecraftClient.field_1690.field_1842) {
                double stamina = class_3532.method_15386(((StaminaUsingEntity) playerEntity).neostamina$getStamina());
                double maxStamina = class_3532.method_15386(((StaminaUsingEntity) playerEntity).neostamina$getMaxStamina());
                double unreservedStamina = class_3532.method_15386(((StaminaUsingEntity) playerEntity).neostamina$getUnreservedStamina());

                if (!playerEntity.method_7337() && maxStamina > 0) {

                    int u = playerEntity.method_5748();
                    int v = Math.min(playerEntity.method_5669(), u);
                    int air_offset = clientConfig.dynamically_adjust_to_air_bar && playerEntity.method_5777(class_3486.field_15517) || v < u ? -10 : 0;
                    int armor_offset = clientConfig.dynamically_adjust_to_armor_bar && playerEntity.method_6096() > 0 ? -10 : 0;

                    MutablePair<Integer, Integer> originPos = ResourceBarAPIClient.getOriginPos(matrixStack, clientConfig.origin);

                    if (clientConfig.stamina_bar_display == ResourceBarAPI.ResourceBarDisplay.ICON && (stamina < maxStamina || clientConfig.show_full_stamina_bar)) {
                        ResourceBarAPIClient.drawIconResourceBar(
                                minecraftClient,
                                matrixStack,
                                RESOURCE_BAR_IDENTIFIER_STRING,
                                stamina,
                                maxStamina,
                                ICON_STAMINA_CONTAINER,
                                ICON_STAMINA_FULL,
                                ICON_STAMINA_HALF,
                                new ArrayList<>(),// TODO reserved stamina
                                new ArrayList<>(),
                                originPos.getLeft(),
                                originPos.getRight(),
                                clientConfig.iconBarSettings.offset_x.get(),
                                clientConfig.iconBarSettings.offset_y.get() + air_offset + armor_offset,
                                clientConfig.fill_direction,
                                clientConfig.iconBarSettings.reverse_stack_direction.get(),
                                clientConfig.iconBarSettings.max_icon_amount_per_bar.get()
                        );
                    } else if (clientConfig.stamina_bar_display == ResourceBarAPI.ResourceBarDisplay.SMOOTH && (stamina < maxStamina || clientConfig.show_full_stamina_bar)) {
                        ResourceBarAPIClient.drawSmoothResourceBar(
                                minecraftClient,
                                matrixStack,
                                RESOURCE_BAR_IDENTIFIER_STRING,
                                new double[]{
                                        -1,
                                        -1,
                                        0,
                                        -91,
                                        -45,
                                        5,
                                        182,
                                        5,
                                        182,
                                        5,
                                        182,
                                        5,
                                        5,
                                        0,
                                        0
                                },
                                new class_2960[]{
                                        class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_background.png"),
                                        class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_progress_decrease_animation.png"),
                                        class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_progress_increase_animation.png"),
                                        class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_progress_increase_value.png"),
                                        class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_progress.png"),
                                        class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_reserved.png"),
                                        class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_overlay.png"),
                                        null
                                },
                                stamina,
                                maxStamina,
                                class_3532.method_15386(((StaminaUsingEntity) playerEntity).neostamina$getRegeneratedStamina()),
                                unreservedStamina,
                                originPos.getLeft(),
                                originPos.getRight(),
                                clientConfig.smoothBarSettings.positionSettings.offsets_x,
                                clientConfig.smoothBarSettings.positionSettings.offsets_y,
                                0,
                                air_offset + armor_offset,
                                clientConfig.fill_direction,
                                clientConfig.smoothBarSettings.textureSettings.backgroundTextureSettings.texture_heights,
                                clientConfig.smoothBarSettings.textureSettings.backgroundTextureSettings.texture_widths,
                                clientConfig.smoothBarSettings.textureSettings.backgroundTextureSettings.texture_ids,
                                clientConfig.smoothBarSettings.textureSettings.progressTextureSettings.offset_x,
                                clientConfig.smoothBarSettings.textureSettings.progressTextureSettings.offset_y,
                                clientConfig.smoothBarSettings.textureSettings.progressTextureSettings.texture_heights,
                                clientConfig.smoothBarSettings.textureSettings.progressTextureSettings.texture_widths,
                                clientConfig.smoothBarSettings.textureSettings.progressTextureSettings.progress_decrease_animation_texture_ids,
                                clientConfig.smoothBarSettings.textureSettings.progressTextureSettings.progress_increase_animation_texture_ids,
                                clientConfig.smoothBarSettings.textureSettings.progressTextureSettings.progress_increase_value_texture_ids,
                                clientConfig.smoothBarSettings.textureSettings.progressTextureSettings.progress_texture_ids,
                                clientConfig.smoothBarSettings.textureSettings.reservedTextureSettings.offset_x,
                                clientConfig.smoothBarSettings.textureSettings.reservedTextureSettings.offset_y,
                                clientConfig.smoothBarSettings.textureSettings.reservedTextureSettings.texture_heights,
                                clientConfig.smoothBarSettings.textureSettings.reservedTextureSettings.texture_widths,
                                clientConfig.smoothBarSettings.textureSettings.reservedTextureSettings.texture_ids,
                                clientConfig.smoothBarSettings.show_current_value_overlay,
                                clientConfig.smoothBarSettings.textureSettings.overlayTextureSettings.offset_x,
                                clientConfig.smoothBarSettings.textureSettings.overlayTextureSettings.offset_y,
                                clientConfig.smoothBarSettings.textureSettings.overlayTextureSettings.texture_heights,
                                clientConfig.smoothBarSettings.textureSettings.overlayTextureSettings.texture_widths,
                                clientConfig.smoothBarSettings.textureSettings.overlayTextureSettings.texture_ids,
                                clientConfig.smoothBarSettings.show_icon,
                                clientConfig.smoothBarSettings.iconTextureSettings.offset_x,
                                clientConfig.smoothBarSettings.iconTextureSettings.offset_y,
                                clientConfig.smoothBarSettings.iconTextureSettings.texture_heights,
                                clientConfig.smoothBarSettings.iconTextureSettings.texture_widths,
                                clientConfig.smoothBarSettings.iconTextureSettings.texture_ids,
                                clientConfig.smoothBarSettings.enable_smooth_animation,
                                clientConfig.smoothBarSettings.animationSettings.animation_interval,
                                clientConfig.smoothBarSettings.animationSettings.max_value_change_is_animated
                        );
                    }
                    if (clientConfig.numberSettings.show_number && (stamina < maxStamina || clientConfig.numberSettings.show_when_stamina_full)) {
                        ResourceBarAPIClient.drawResourceNumber(
                                minecraftClient,
                                minecraftClient.field_1772,
                                matrixStack,
                                RESOURCE_BAR_IDENTIFIER_STRING,
                                stamina,
                                maxStamina,
                                unreservedStamina,
                                originPos.getLeft(),
                                originPos.getRight(),
                                clientConfig.numberSettings.show_max_value,
                                clientConfig.numberSettings.offset_x,
                                clientConfig.numberSettings.offset_y + air_offset + armor_offset,
                                clientConfig.numberSettings.color.toInt()
                        );
                    }
                }
            }
        });
        ConfigApi.event().onUpdateClient((identifier, config) -> {
            if (identifier.equals(class_2960.method_60655(Neostamina.MOD_ID, "client"))) {
                ResourceBarAPIClient.clearCache(
                        RESOURCE_BAR_IDENTIFIER_STRING,
                        new double[]{
                                -1,
                                -1,
                                0,
                                -91,
                                -45,
                                5,
                                182,
                                5,
                                182,
                                5,
                                182,
                                5,
                                5,
                                0,
                                0
                        },
                        new class_2960[]{
                                class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_background.png"),
                                class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_progress_decrease_animation.png"),
                                class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_progress_increase_animation.png"),
                                class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_progress_increase_value.png"),
                                class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_progress.png"),
                                class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_reserved.png"),
                                class_2960.method_60655("neostamina", "textures/gui/sprites/hud/horizontal_stamina_overlay.png"),
                                null
                        }
                );
            }
        });
    }
}
