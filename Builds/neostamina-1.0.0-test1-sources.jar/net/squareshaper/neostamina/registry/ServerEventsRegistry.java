package net.squareshaper.neostamina.registry;

import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1271;
import net.minecraft.class_1799;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;

public class ServerEventsRegistry {
    public static void init() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 itemStack = player.method_5998(hand);
            if (itemStack.method_31573(Neostamina.USING_COSTS_STAMINA)) {
                if (((StaminaUsingEntity) player).neostamina$getStamina() <= 0 && ((StaminaUsingEntity) player).neostamina$getItemUseStaminaCost() > 0) {
                    player.method_7357().method_7906(itemStack.method_7909(), Neostamina.SERVER_CONFIG.item_use_cooldown_when_no_stamina);
                    return class_1271.method_22431(itemStack);
                }
                ((StaminaUsingEntity) player).neostamina$addStamina(-((StaminaUsingEntity) player).neostamina$getItemUseStaminaCost());
            }
            return class_1271.method_22430(itemStack);
        });
    }
}
