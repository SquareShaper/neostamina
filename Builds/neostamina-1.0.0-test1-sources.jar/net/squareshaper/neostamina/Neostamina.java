package net.squareshaper.neostamina;

import me.fzzyhmstrs.fzzy_config.api.ConfigApiJava;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1320;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.squareshaper.neostamina.config.ServerConfig;
import net.squareshaper.neostamina.registry.ServerEventsRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Neostamina implements ModInitializer {
	public static final String MOD_ID = "neostamina";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static ServerConfig SERVER_CONFIG;

	public static class_6880<class_1320> STAMINA_REGENERATION;
	public static class_6880<class_1320> BASE_STAMINA;
	public static class_6880<class_1320> BOOSTED_STAMINA;
	public static class_6880<class_1320> MAX_STAMINA;
	public static class_6880<class_1320> DEPLETED_STAMINA_REGENERATION_DELAY_THRESHOLD;
	public static class_6880<class_1320> STAMINA_REGENERATION_DELAY_THRESHOLD;
	public static class_6880<class_1320> STAMINA_TICK_THRESHOLD;
	public static class_6880<class_1320> RESERVED_STAMINA;
	public static class_6880<class_1320> ITEM_USE_STAMINA_COST;
	public static class_6880<class_1320> SPRINTING_TICK_STAMINA_COST;
//	public static RegistryEntry<EntityAttribute> SNEAKING_TICK_STAMINA_COST; // don't need this
	public static class_6880<class_1320> WALKING_TICK_STAMINA_COST;
	public static class_6880<class_1320> SWIMMING_TICK_STAMINA_COST;
	public static class_6880<class_1320> WALKING_UNDERWATER_TICK_STAMINA_COST;
	public static class_6880<class_1320> WALKING_IN_WATER_TICK_STAMINA_COST;
	public static class_6880<class_1320> CLIMBING_TICK_STAMINA_COST;
	public static class_6880<class_1320> JUMPING_ACTION_STAMINA_COST;
	public static class_6880<class_1320> SPRINT_JUMPING_ACTION_STAMINA_COST;

	public static final class_6862<class_1792> USING_COSTS_STAMINA = class_6862.method_40092(class_7924.field_41197, id("using_costs_stamina"));
	public static final class_6862<class_1792> CONTINUOUS_USING_COSTS_STAMINA = class_6862.method_40092(class_7924.field_41197, id("continuous_using_costs_stamina"));

	@Override
	public void onInitialize() {
		LOGGER.info("Initializing Neostamina!");
		LOGGER.info("(thx @TheRedBrain!)");
		SERVER_CONFIG = ConfigApiJava.registerAndLoadConfig(ServerConfig::new);

		ServerEventsRegistry.init();
	}

	public static class_2960 id(String path) {
		return class_2960.method_60655(MOD_ID, path);
	}
}
