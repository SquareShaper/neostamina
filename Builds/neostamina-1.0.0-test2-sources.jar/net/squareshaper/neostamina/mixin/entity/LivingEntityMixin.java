package net.squareshaper.neostamina.mixin.entity;


import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3532;
import net.minecraft.class_5132;
import net.minecraft.class_6880;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 implements StaminaUsingEntity {

    @Shadow
    public abstract double getAttributeValue(class_6880<class_1320> attribute);

    @Shadow
    public abstract boolean isUsingItem();

    @Shadow
    public abstract void stopUsingItem();

    @Shadow
    protected class_1799 activeItemStack;

    @Unique
    private int staminaTickTimer = 0;
    @Unique
    private int depletedStaminaRegenerationDelayTimer = 0;
    @Unique
    private int staminaRegenerationDelayTimer = 0;
    @Unique
    private boolean delayStaminaRegeneration = false;
    @Unique
    private Float oldStamina = null;
    @Unique
    private Float oldMaxStamina = null;
    @Unique
    private boolean applyOldStamina = true;
    @Unique
    private boolean applyMaxStamina = false;
    @Unique
    private boolean nerfMaxStamina = false;

    @Unique
    private static final class_2940<Float> STAMINA = class_2945.method_12791(class_1309.class, class_2943.field_13320);
    @Unique
    private static final class_2940<Float> MAX_STAMINA = class_2945.method_12791(class_1309.class, class_2943.field_13320);

    public LivingEntityMixin(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Inject(method = "initDataTracker", at = @At("RETURN"))
    protected void neostamina$initDataTracker(class_2945.class_9222 builder, CallbackInfo ci) {
        builder.method_56912(STAMINA, 20.0F);
        builder.method_56912(MAX_STAMINA, 20.0F);
    }

    @Inject(method = "createLivingAttributes", at = @At("RETURN"))
    private static void neostamina$createLivingAttributes(CallbackInfoReturnable<class_5132.class_5133> cir) {
        cir.getReturnValue()
                .method_26867(Neostamina.STAMINA_REGENERATION)
                .method_26867(Neostamina.BASE_STAMINA)
                .method_26867(Neostamina.BOOSTED_STAMINA)
                .method_26867(Neostamina.MAX_STAMINA)
                .method_26867(Neostamina.MAX_STAMINA_CHANGE)
                .method_26867(Neostamina.DEPLETED_STAMINA_REGENERATION_DELAY_THRESHOLD)
                .method_26867(Neostamina.STAMINA_REGENERATION_DELAY_THRESHOLD)
                .method_26867(Neostamina.STAMINA_TICK_THRESHOLD)
                .method_26867(Neostamina.RESERVED_STAMINA)
                .method_26867(Neostamina.ITEM_USE_STAMINA_COST)
                .method_26867(Neostamina.SPRINTING_TICK_STAMINA_COST)
//                .add(Neostamina.SNEAKING_TICK_STAMINA_COST) don't need dis
                .method_26867(Neostamina.WALKING_TICK_STAMINA_COST)
                .method_26867(Neostamina.SWIMMING_TICK_STAMINA_COST)
                .method_26867(Neostamina.WALKING_UNDERWATER_TICK_STAMINA_COST)
                .method_26867(Neostamina.WALKING_IN_WATER_TICK_STAMINA_COST)
                .method_26867(Neostamina.CLIMBING_TICK_STAMINA_COST)
                .method_26867(Neostamina.JUMPING_ACTION_STAMINA_COST)
                .method_26867(Neostamina.SPRINT_JUMPING_ACTION_STAMINA_COST)
        ;
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("HEAD"))
    public void neostamina$readCustomDataFromNbt_head(class_2487 nbt, CallbackInfo ci) {
        float stamina;
        if (nbt.method_10573("stamina", class_2520.field_33263)) {
            stamina = nbt.method_10583("stamina");
        } else {
            stamina = Float.MIN_VALUE;
        }
        if (stamina != Float.MIN_VALUE) {
            this.oldStamina = stamina;
        }

        float maxStamina;
        if (nbt.method_10573("max_stamina", class_2520.field_33263)) {
            maxStamina = nbt.method_10583("max_stamina");
        } else {
            maxStamina = Float.MIN_VALUE;
        }
        if (maxStamina != Float.MIN_VALUE) {
            this.oldMaxStamina = maxStamina;
        }
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    public void neostamina$readCustomDataFromNbt_tail(class_2487 nbt, CallbackInfo ci) {
        if (nbt.method_10573("stamina", class_2520.field_33263)) {
            this.neostamina$setStamina(nbt.method_10583("stamina"));
        }

        if (nbt.method_10573("max_stamina", class_2520.field_33263)) {
            this.neostamina$setMaxStamina(nbt.method_10583("max_stamina"));
        }
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    public void neostamina$writeCustomDataToNbt(class_2487 nbt, CallbackInfo ci) {
        nbt.method_10548("max_stamina", this.neostamina$getMaxStamina());
        nbt.method_10548("stamina", this.neostamina$getStamina());
    }

    @Inject(method = "tick", at = @At("TAIL"))
    public void neostamina$tick(CallbackInfo ci) {
        if (this.nerfMaxStamina) {
            this.neostamina$addStamina(-this.neostamina$getMaxStaminaChange());
            this.neostamina$addMaxStamina(-this.neostamina$getMaxStaminaChange());
            this.neostamina$setNerfMaxStamina(false);
        }
        if (!this.method_37908().field_9236) {

            this.staminaTickTimer++;

            if (this.neostamina$getStamina() <= 0 && this.delayStaminaRegeneration) {
                this.depletedStaminaRegenerationDelayTimer = 0;
                this.staminaRegenerationDelayTimer = this.neostamina$getStaminaRegenerationDelayThreshold();
                this.delayStaminaRegeneration = false;
            }
            if (this.neostamina$getStamina() > 0 && !this.delayStaminaRegeneration) {
                this.delayStaminaRegeneration = true;
            }
            if (this.depletedStaminaRegenerationDelayTimer <= this.neostamina$getDepletedStaminaRegenerationDelayThreshold()) {
                this.depletedStaminaRegenerationDelayTimer++;
            }
            if (this.staminaRegenerationDelayTimer <= this.neostamina$getStaminaRegenerationDelayThreshold()) {
                this.staminaRegenerationDelayTimer++;
            }

            if (
                    this.staminaTickTimer > this.neostamina$getStaminaTickThreshold()
                            && this.depletedStaminaRegenerationDelayTimer > this.neostamina$getDepletedStaminaRegenerationDelayThreshold()
                            && this.staminaRegenerationDelayTimer > this.neostamina$getStaminaRegenerationDelayThreshold()
            ) {
                if (this.neostamina$getStamina() < this.neostamina$getUnreservedStamina()) {
                    this.neostamina$addStamina(this.neostamina$getRegeneratedStamina());
                }
                if (this.neostamina$getStamina() > this.neostamina$getUnreservedStamina() || this.neostamina$getRegeneratedStamina() < 0) {
                    this.neostamina$setStamina(this.neostamina$getUnreservedStamina());
                }
                this.staminaTickTimer = 0;
            }

            if (this.isUsingItem() && this.activeItemStack.method_31573(Neostamina.CONTINUOUS_USING_COSTS_STAMINA) && this.neostamina$getItemUseStaminaCost() > 0 && this.neostamina$getStamina() <= 0) {
                if (((class_1309) (Object) this) instanceof class_1657 playerEntity) {
                    playerEntity.method_7357().method_7906(this.activeItemStack.method_7909(), Neostamina.SERVER_CONFIG.item_use_cooldown_when_no_stamina);
                }
                this.stopUsingItem();
            }
            if (this.applyOldStamina) {
                if (this.applyMaxStamina) {
                    this.oldStamina = this.neostamina$getBoostedStamina();
                    this.oldMaxStamina = this.neostamina$getBoostedStamina();
                    this.applyMaxStamina = false;
                }
                if (this.oldMaxStamina != null) {
                    this.neostamina$setMaxStamina(this.oldMaxStamina);
                    this.oldMaxStamina = null;
                }
                if (this.oldStamina != null) {
                    this.neostamina$setStamina(this.oldStamina);
                    this.oldStamina = null;
                }
            } else {
                this.applyOldStamina = true;
            }
        }
    }

    @Inject(method = "tickItemStackUsage", at = @At("HEAD"))
    protected void neostamina$tickItemStackUsage(class_1799 stack, CallbackInfo ci) {
        if (stack.method_31573(Neostamina.CONTINUOUS_USING_COSTS_STAMINA) && neostamina$getItemUseStaminaCost() > 0 && neostamina$getStamina() > 0) {
            this.neostamina$addStamina(-neostamina$getItemUseStaminaCost());
        }
    }

    @Override
    public int neostamina$getDepletedStaminaRegenerationDelayThreshold() {
        return (int) this.getAttributeValue(Neostamina.DEPLETED_STAMINA_REGENERATION_DELAY_THRESHOLD);
    }

    @Override
    public int neostamina$getStaminaRegenerationDelayThreshold() {
        return (int) this.getAttributeValue(Neostamina.STAMINA_REGENERATION_DELAY_THRESHOLD);
    }

    @Override
    public int neostamina$getStaminaTickThreshold() {
        return (int) this.getAttributeValue(Neostamina.STAMINA_TICK_THRESHOLD);
    }

    @Override
    public float neostamina$getRegeneratedStamina() {
        return this.neostamina$getStaminaRegeneration();
    }

    @Override
    public float neostamina$getStaminaRegeneration() {
        return (float) this.getAttributeValue(Neostamina.STAMINA_REGENERATION);
    }

    @Override
    public float neostamina$getUnreservedStamina() {
        return this.neostamina$getMaxStamina() - ((this.neostamina$getMaxStamina() * this.neostamina$getReservedStamina()) / 100);
    }

    @Override
    public float neostamina$getBaseStamina() {
        return (float) this.getAttributeValue(Neostamina.BASE_STAMINA);
    }

    @Override
    public float neostamina$getBoostedStamina() {
        return (float) this.getAttributeValue(Neostamina.BOOSTED_STAMINA);
    }

    @Override
    public float neostamina$getMaxStamina() {
        return this.field_6011.method_12789(MAX_STAMINA);
    }

    @Override
    public float neostamina$getReservedStamina() {
        return (float) this.getAttributeValue(Neostamina.RESERVED_STAMINA);
    }

    @Override
    public float neostamina$getItemUseStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.ITEM_USE_STAMINA_COST);
    }

    @Override
    public float neostamina$getSprintingTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.SPRINTING_TICK_STAMINA_COST);
    }

//    @Override
//    public float neostamina$getSneakingTickStaminaCost() {
//        return (float) this.getAttributeValue(Neostamina.SNEAKING_TICK_STAMINA_COST);
//    }

    @Override
    public float neostamina$getWalkingTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.WALKING_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getSwimmingTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.SWIMMING_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getWalkingUnderwaterTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.WALKING_UNDERWATER_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getWalkingInWaterTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.WALKING_IN_WATER_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getClimbingTickStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.CLIMBING_TICK_STAMINA_COST);
    }

    @Override
    public float neostamina$getJumpingActionStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.JUMPING_ACTION_STAMINA_COST);
    }

    @Override
    public float neostamina$getSprintJumpingActionStaminaCost() {
        return (float) this.getAttributeValue(Neostamina.SPRINT_JUMPING_ACTION_STAMINA_COST);
    }

    @Override
    public void neostamina$addStamina(float amount) {
        float f = this.neostamina$getStamina();
        this.neostamina$setStamina(f + amount);
        if (amount < 0) {
            this.staminaRegenerationDelayTimer = 0;
            this.staminaTickTimer = 0;
        }
    }

    @Override
    public float neostamina$getStamina() {
        return this.field_6011.method_12789(STAMINA);
    }

    @Override
    public void neostamina$setStamina(float stamina) {
        this.field_6011.method_12778(STAMINA, class_3532.method_15363(stamina, -0.1F, this.neostamina$getUnreservedStamina()));
    }

    @Override
    public void neostamina$setApplyOldStamina(boolean applyOldStamina) {
        this.applyOldStamina = applyOldStamina;
    }

    @Override
    public void neostamina$setApplyMaxStamina(boolean applyMaxStamina) {
        this.applyMaxStamina = applyMaxStamina;
    }

    @Override
    public void neostamina$setNerfMaxStamina(boolean nerfMaxStamina) {
        this.nerfMaxStamina = nerfMaxStamina;
    }

    @Override
    public void neostamina$addMaxStamina(float maxStamina) {
        this.neostamina$setMaxStamina(this.neostamina$getMaxStamina() + maxStamina);
    }

    @Override
    public void neostamina$setMaxStamina(float maxStamina) {
        this.field_6011.method_12778(MAX_STAMINA, class_3532.method_15363(maxStamina, this.neostamina$getBaseStamina(), this.neostamina$getBoostedStamina()));
    }

    @Override
    public void neostamina$boostMaxStamina() {
        this.neostamina$setMaxStamina(this.neostamina$getBoostedStamina());
        this.neostamina$setStamina(this.neostamina$getBoostedStamina());
    }

    @Override
    public float neostamina$getMaxStaminaChange() {
        return (float) this.getAttributeValue(Neostamina.MAX_STAMINA_CHANGE);
    }
}
