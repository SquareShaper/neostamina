package net.squareshaper.neostamina.mixin.client.network;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_636.class)
public abstract class ClientPlayerInteractionManagerMixin {

    @Shadow
    @Final
    private class_310 client;

    @Shadow
    private class_2338 currentBreakingPos;

    @Shadow
    public abstract void cancelBlockBreaking();

    @Shadow
    public abstract boolean isBreakingBlock();

    @WrapMethod(method = "isCurrentlyBreaking")
    private boolean neostamina$breakingBlock(class_2338 pos, Operation<Boolean> original) {
        if (Neostamina.SERVER_CONFIG.breaking_blocks_is_blocked_by_stamina && ((StaminaUsingEntity) this.client.field_1724).neostamina$getStamina() <= 0 && pos.equals(this.currentBreakingPos)) {
            this.cancelBlockBreaking();
            this.client.field_1687.method_8517(this.client.field_1724.method_5628(), this.currentBreakingPos, 0);
        }
        return original.call(pos);
    }

    @WrapMethod(method = "interactBlock")
    private class_1269 neostamina$interactingBlock(class_746 player, class_1268 hand, class_3965 hitResult, Operation<class_1269> original) {
        class_1269 result = original.call(player, hand, hitResult);
        //TODO: Make this work via server packets uwu much pain (maybe not relevant anymore?)
        if (client.field_1724.method_7337() || client.field_1724.method_7325() || !(result == class_1269.field_51370 || result == class_1269.field_5812)) {
            return result;
        }
        if (Neostamina.SERVER_CONFIG.interacting_is_blocked_by_stamina) {
            if (((StaminaUsingEntity) player).neostamina$getStamina() <= 0) {
                return class_1269.field_5814;
            }
        }
        if (Neostamina.SERVER_CONFIG.interacting_costs_stamina) {
            ((StaminaUsingEntity) player).neostamina$addStamina(-((StaminaUsingEntity) player).neostamina$getInteractionActionStaminaCost(), true);
        }


        return result;
    }

    // TODO: Make a method for costing stamina when breaking
    @Inject(method = "tick", at = @At("TAIL"))
    private void neostamina$doBlockBreakingCosts(CallbackInfo ci) {
        //if (this.isBreakingBlock())
    }
}
