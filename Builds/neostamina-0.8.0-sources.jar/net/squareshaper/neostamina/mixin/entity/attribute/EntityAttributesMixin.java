package net.squareshaper.neostamina.mixin.entity.attribute;

import net.minecraft.class_1329;
import net.minecraft.class_2378;
import net.minecraft.class_5134;
import net.minecraft.class_7923;
import net.squareshaper.neostamina.Neostamina;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_5134.class)
public class EntityAttributesMixin {
    static {
        Neostamina.STAMINA_REGENERATION = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.stamina_regeneration"), new class_1329("attribute.name.generic.stamina_regeneration", 0.5F, -65536.0F, 65536.0F).method_26829(true));
        Neostamina.MIN_MAX_STAMINA = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.min_max_stamina"), new class_1329("attribute.name.generic.min_max_stamina", 100.0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.MAX_STAMINA = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.max_stamina"), new class_1329("attribute.name.generic.max_stamina", 2000.0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.DEPLETED_STAMINA_REGENERATION_DELAY_THRESHOLD = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.depleted_stamina_regeneration_delay_threshold"), new class_1329("attribute.name.generic.depleted_stamina_regeneration_delay_threshold", 60.0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.STAMINA_REGENERATION_DELAY_THRESHOLD = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.stamina_regeneration_delay_threshold"), new class_1329("attribute.name.generic.stamina_regeneration_delay_threshold", 20.0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.STAMINA_TICK_THRESHOLD = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.stamina_tick_threshold"), new class_1329("attribute.name.generic.stamina_tick_threshold", 20.0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.RESERVED_STAMINA = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.reserved_stamina"), new class_1329("attribute.name.generic.reserved_stamina", 0.0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.ITEM_SINGLE_USE_STAMINA_COST  = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.item_single_use_stamina_cost"), new class_1329("attribute.name.generic.item_single_use_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.ITEM_CONTINUOUS_USE_STAMINA_COST  = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.item_continuous_use_stamina_cost"), new class_1329("attribute.name.generic.item_continuous_use_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.SPRINTING_TICK_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.sprinting_tick_stamina_cost"), new class_1329("attribute.name.generic.sprinting_tick_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.WALKING_TICK_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.walking_tick_stamina_cost"), new class_1329("attribute.name.generic.walking_tick_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.CRAWLING_TICK_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.crawling_tick_stamina_cost"), new class_1329("attribute.name.generic.crawling_tick_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.SWIMMING_TICK_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.swimming_tick_stamina_cost"), new class_1329("attribute.name.generic.swimming_tick_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.WALKING_UNDERWATER_TICK_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.walking_underwater_tick_stamina_cost"), new class_1329("attribute.name.generic.walking_underwater_tick_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.WALKING_IN_WATER_TICK_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.walking_in_water_tick_stamina_cost"), new class_1329("attribute.name.generic.walking_in_water_tick_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.CLIMBING_TICK_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.climbing_tick_stamina_cost"), new class_1329("attribute.name.generic.climbing_tick_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.MINING_TICK_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.mining_tick_stamina_cost"), new class_1329("attribute.name.generic.mining_tick_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.ROWING_LAND_TICK_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.rowing_land_tick_stamina_cost"), new class_1329("attribute.name.generic.rowing_land_tick_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.ROWING_WATER_TICK_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.rowing_water_tick_stamina_cost"), new class_1329("attribute.name.generic.rowing_water_tick_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.ROWING_ICE_TICK_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.rowing_ice_tick_stamina_cost"), new class_1329("attribute.name.generic.rowing_ice_tick_stamina_cost", 0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.JUMPING_ACTION_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.jumping_action_stamina_cost"), new class_1329("attribute.name.generic.jumping_action_stamina_cost", 0.0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.SPRINT_JUMPING_ACTION_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.sprint_jumping_action_stamina_cost"), new class_1329("attribute.name.generic.sprint_jumping_action_stamina_cost", 0.0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.ATTACKING_ACTION_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.attacking_action_stamina_cost"), new class_1329("attribute.name.generic.attacking_action_stamina_cost", 0.0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.INTERACTION_ACTION_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.interaction_action_stamina_cost"), new class_1329("attribute.name.generic.interaction_action_stamina_cost", 0.0F, 0.0F, 65536.0F).method_26829(true));
        Neostamina.SHIELD_BLOCK_ACTION_STAMINA_COST = class_2378.method_47985(class_7923.field_41190, Neostamina.id("generic.shield_block_action_stamina_cost"), new class_1329("attribute.name.generic.shield_block_action_stamina_cost", 0.0F, 0.0F, 65536.0F).method_26829(true));
    }

}
