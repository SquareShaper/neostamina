package net.squareshaper.neostamina.mixin.server.network;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3442;
import net.minecraft.class_3468;
import net.minecraft.class_3481;
import net.minecraft.class_4050;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3222.class)
public abstract class ServerPlayerEntityMixin extends class_1657 implements StaminaUsingEntity {

    @Shadow public abstract class_3442 getStatHandler();

    @Shadow
    public abstract class_3218 getServerWorld();

    public ServerPlayerEntityMixin(class_1937 world, class_2338 pos, float yaw, GameProfile gameProfile) {
        super(world, pos, yaw, gameProfile);
    }

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 0))
    private void neostamina$increaseTravelMotionStats_swimming(CallbackInfo ci) {
        if (!this.method_7337() && !this.method_7325() && Neostamina.SERVER_CONFIG.swimming_costs_stamina && this.neostamina$getSwimmingTickStaminaCost() > 0) {
            this.neostamina$addStamina(-this.neostamina$getSwimmingTickStaminaCost(), true);
        }
    }

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 1))
    private void neostamina$increaseTravelMotionStats_walk_underwater(CallbackInfo ci) {
        if (!this.method_7337() && !this.method_7325() && Neostamina.SERVER_CONFIG.walking_costs_stamina && this.neostamina$getWalkingUnderwaterTickStaminaCost() > 0 && !this.method_5715()) {
            this.neostamina$addStamina(-this.neostamina$getWalkingUnderwaterTickStaminaCost(), true);
        }
    }

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 2))
    private void neostamina$increaseTravelMotionStats_walk_in_water(CallbackInfo ci) {
        if (!this.method_7337() && !this.method_7325() && Neostamina.SERVER_CONFIG.walking_costs_stamina && this.neostamina$getWalkingInWaterTickStaminaCost() > 0 && !this.method_5715()) {
            this.neostamina$addStamina(-this.neostamina$getWalkingInWaterTickStaminaCost(), true);
        }
    }

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;increaseStat(Lnet/minecraft/util/Identifier;I)V", ordinal = 3))
    private void neostamina$increaseTravelMotionStats_climbing(CallbackInfo ci) {
        if (!this.method_7337() && !this.method_7325() && Neostamina.SERVER_CONFIG.climbing_costs_stamina && this.neostamina$getClimbingTickStaminaCost() > 0) {
            this.neostamina$addStamina(-this.neostamina$getClimbingTickStaminaCost(), true);
        }
    }

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 3))
    private void neostamina$increaseTravelMotionStats_sprinting(CallbackInfo ci) {
        if (!this.method_7337() && !this.method_7325() && Neostamina.SERVER_CONFIG.sprinting_costs_stamina && this.neostamina$getSprintingTickStaminaCost() > 0) {
            this.neostamina$addStamina(-this.neostamina$getSprintingTickStaminaCost(), true);
        }
    }

//    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 4))
//    private void neostamina$increaseTravelMotionStats_sneaking(CallbackInfo ci) {
//        if (!this.getAbilities().invulnerable) {
//            this.neostamina$addStamina(-this.neostamina$getSneakingTickStaminaCost());
//        }
//    } // no sneaking uwu

    @Inject(method = "increaseTravelMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;addExhaustion(F)V", ordinal = 5))
    private void neostamina$increaseTravelMotionStats_walking(CallbackInfo ci) {
        if (!this.method_7337() && !this.method_7325() && Neostamina.SERVER_CONFIG.crawling_costs_stamina && this.neostamina$getCrawlingTickStaminaCost() > 0 && !this.method_5715() && !this.method_5681()) {
            if (this.method_52558(class_4050.field_18079) && !this.method_52558(class_4050.field_18081)) {
                // These requirements are from updatePose() in PlayerEntity - if testing shows that it applies to non crawling as well,
                // go there and figure stuff out
                this.neostamina$addStamina(-this.neostamina$getCrawlingTickStaminaCost(), true);
            } else {
                this.neostamina$addStamina(-this.neostamina$getWalkingTickStaminaCost(), false);
            }
        }
    }

    @Inject(method = "increaseRidingMotionStats", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;increaseStat(Lnet/minecraft/util/Identifier;I)V", ordinal = 1))
    private void neostamina$increaseRidingMotionStats_boat(double deltaX, double deltaY, double deltaZ, CallbackInfo ci) {
        class_3218 world = this.getServerWorld();

        if(!Neostamina.SERVER_CONFIG.rowing_costs_stamina || this.method_7337() || this.method_7325()) {
            return;
        }

        if (!world.method_8320(this.method_24515()).method_26227().method_15769()) {
            // Water costs
            if (this.neostamina$getRowingWaterTickStaminaCost() > 0) {
                this.neostamina$addStamina(-this.neostamina$getRowingWaterTickStaminaCost(), true);
            }
        } else if (world.method_8320(this.method_24515()).method_26164(class_3481.field_15467)) {
            //ice costs
            if (this.neostamina$getRowingIceTickStaminaCost() > 0) {
                this.neostamina$addStamina(-this.neostamina$getRowingIceTickStaminaCost(), true);
            }
        } else {
            // land costs
            if (this.neostamina$getRowingLandTickStaminaCost() > 0) {
                this.neostamina$addStamina(-this.neostamina$getRowingLandTickStaminaCost(), true);
            }
        }
    }

    @Inject(method = "onSpawn", at = @At("TAIL"))
    public void neostamina$onSpawn(CallbackInfo ci) {
        this.neostamina$setApplyOldStamina(false);
        if (this.getStatHandler().method_15025(class_3468.field_15419.method_14956(class_3468.field_15389)) <= 0) {
            this.neostamina$setApplyMaxStamina(true);
        }
    }
}
