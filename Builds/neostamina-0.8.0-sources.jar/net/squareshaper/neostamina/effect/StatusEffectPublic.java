package net.squareshaper.neostamina.effect;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

public class StatusEffectPublic extends class_1291 {
    public StatusEffectPublic(class_4081 category, int color) {
        super(category, color);
    }
}
