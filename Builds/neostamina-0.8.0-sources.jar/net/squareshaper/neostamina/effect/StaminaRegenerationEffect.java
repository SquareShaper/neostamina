package net.squareshaper.neostamina.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_4081;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;

public class StaminaRegenerationEffect extends class_1291 {
    public StaminaRegenerationEffect(class_4081 category, int color) {
        super(category, color);
    }

    @Override
    public boolean method_5572(class_1309 entity, int amplifier) {
        if (entity instanceof StaminaUsingEntity staminaUsingEntity) {
            staminaUsingEntity.neostamina$addStamina(Neostamina.SERVER_CONFIG.stamina_regeneration_effect * (amplifier + 1), false);
        }
        return super.method_5572(entity, amplifier);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        return true;
    }
}
