package net.squareshaper.neostamina.registry;

import net.fabricmc.fabric.api.registry.FabricBrewingRecipeRegistryBuilder;
import net.minecraft.class_1293;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1847;
import net.minecraft.class_2378;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.squareshaper.neostamina.Neostamina;

public class PotionRegistry {



    public static final class_6880<class_1842> STAMINA_REGENERATION = register("stamina_regeneration", new class_1842(new class_1293(StatusEffectsRegistry.STAMINA_REGENERATION, 900)));
    public static final class_6880<class_1842> LONG_STAMINA_REGENERATION = register("long_stamina_regeneration", new class_1842("stamina_regeneration", new class_1293(StatusEffectsRegistry.STAMINA_REGENERATION, 1800)));
    public static final class_6880<class_1842> STRONG_STAMINA_REGENERATION = register("strong_stamina_regeneration", new class_1842("stamina_regeneration", new class_1293(StatusEffectsRegistry.STAMINA_REGENERATION, 450, 1)));

    public static void init() {
        FabricBrewingRecipeRegistryBuilder.BUILD.register(builder -> {
            builder.method_59705(class_1847.field_8999, class_1802.field_8479, STAMINA_REGENERATION);
            builder.method_59705(STAMINA_REGENERATION, class_1802.field_8725, LONG_STAMINA_REGENERATION);
            builder.method_59705(STAMINA_REGENERATION, class_1802.field_8054, STRONG_STAMINA_REGENERATION);
        });
    }

    private static class_6880<class_1842> register(String name, class_1842 potion) {
        return class_2378.method_47985(class_7923.field_41179, Neostamina.id(name), potion);
    }
}
