package net.squareshaper.neostamina.registry;

import net.fabricmc.fabric.api.event.player.*;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1799;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.entity.StaminaUsingEntity;

public class ServerEventsRegistry {
    public static void init() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 itemStack = player.method_5998(hand);
            if (player.method_7337() || player.method_7325() || !itemStack.method_31573(Neostamina.USING_COSTS_STAMINA)) {
                return class_1271.method_22430(itemStack);
            }

            if (Neostamina.SERVER_CONFIG.using_item_is_blocked_by_stamina && ((StaminaUsingEntity) player).neostamina$getStamina() <= 0) {
                player.method_7357().method_7906(itemStack.method_7909(), Neostamina.SERVER_CONFIG.item_use_cooldown_when_no_stamina);
                return class_1271.method_22431(itemStack);
            }
            if (Neostamina.SERVER_CONFIG.using_item_costs_stamina && ((StaminaUsingEntity) player).neostamina$getItemSingleUseStaminaCost() > 0) {
                ((StaminaUsingEntity) player).neostamina$addStamina(-((StaminaUsingEntity) player).neostamina$getItemSingleUseStaminaCost(), true);
            }

            return class_1271.method_22430(itemStack);
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (player.method_7337() || player.method_7325()) {
                return class_1269.field_5811;
            }

            if (Neostamina.SERVER_CONFIG.attacking_is_blocked_by_stamina && ((StaminaUsingEntity) player).neostamina$getStamina() <= 0) {
                return class_1269.field_5814;
            }
            if (Neostamina.SERVER_CONFIG.attacking_costs_stamina && ((StaminaUsingEntity) player).neostamina$getAttackActionStaminaCost() > 0) {
                ((StaminaUsingEntity) player).neostamina$addStamina(-((StaminaUsingEntity) player).neostamina$getAttackActionStaminaCost(), true);
            }

            return class_1269.field_5811;
        });

        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (player.method_7337() || player.method_7325()) {
                return class_1269.field_5811;
            }

            if (Neostamina.SERVER_CONFIG.breaking_blocks_is_blocked_by_stamina && ((StaminaUsingEntity) player).neostamina$getStamina() <= 0) {
                return class_1269.field_5814;
            }
            if (Neostamina.SERVER_CONFIG.breaking_blocks_costs_stamina && ((StaminaUsingEntity) player).neostamina$getMiningTickStaminaCost() > 0) {
                ((StaminaUsingEntity) player).neostamina$addStamina(-((StaminaUsingEntity) player).neostamina$getMiningTickStaminaCost(), true);
            }


            return class_1269.field_5811;
        });

//        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
//            if (!player.isSpectator() && !player.isCreative() && Neostamina.SERVER_CONFIG.interacting_requires_stamina && ((StaminaUsingEntity) player).neostamina$getInteractionActionStaminaCost() > 0) {
//                if (((StaminaUsingEntity) player).neostamina$getStamina() <= 0) {
//                    return ActionResult.FAIL;
//                }
//                ((StaminaUsingEntity) player).neostamina$addStamina(-((StaminaUsingEntity) player).neostamina$getInteractionActionStaminaCost(), true);
//            }
//            return ActionResult.PASS;
//        });
//
//        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
//            if (!player.isSpectator() && !player.isCreative() && Neostamina.SERVER_CONFIG.interacting_requires_stamina && ((StaminaUsingEntity) player).neostamina$getInteractionActionStaminaCost() > 0) {
//                if (((StaminaUsingEntity) player).neostamina$getStamina() <= 0) {
//                    return ActionResult.FAIL;
//                }
//                ((StaminaUsingEntity) player).neostamina$addStamina(-((StaminaUsingEntity) player).neostamina$getInteractionActionStaminaCost(), true);
//            }
//            return ActionResult.PASS;
//        });
    }
}
