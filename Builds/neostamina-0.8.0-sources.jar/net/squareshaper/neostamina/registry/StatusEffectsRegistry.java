package net.squareshaper.neostamina.registry;

import net.minecraft.class_1291;
import net.minecraft.class_1322;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4081;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.squareshaper.neostamina.Neostamina;
import net.squareshaper.neostamina.effect.StaminaRegenerationEffect;
import net.squareshaper.neostamina.effect.StatusEffectPublic;

public class StatusEffectsRegistry {
    public static final class_6880<class_1291> STAMINA_REGENERATION = register("stamina_regeneration", new StaminaRegenerationEffect(class_4081.field_18271, 0xd4af37));
    public static final class_6880<class_1291> EXHAUSTION = register("exhaustion", new StatusEffectPublic(class_4081.field_18272, 0x63471a)
            .method_5566(class_5134.field_23721, class_2960.method_60656("effect.weakness"), -4.0, class_1322.class_1323.field_6331)
            .method_5566(class_5134.field_23719, class_2960.method_60656("effect.slowness"), -0.15F, class_1322.class_1323.field_6331)
            .method_5566(class_5134.field_23723, class_2960.method_60656("effect.mining_fatigue"), -0.1F, class_1322.class_1323.field_6331));

    public static void init() {}

    private static class_6880<class_1291> register(String name, class_1291 effect) {
        return class_2378.method_47985(class_7923.field_41174, Neostamina.id(name), effect);
    }
}
